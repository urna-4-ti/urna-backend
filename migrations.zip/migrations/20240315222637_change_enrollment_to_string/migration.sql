-- AlterTable
ALTER TABLE "User" ALTER COLUMN "enrollment" SET DATA TYPE TEXT;
